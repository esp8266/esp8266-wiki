# Defaults for esptool initscript
# sourced by /etc/init.d/esptool
# installed at /etc/default/esptool by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
