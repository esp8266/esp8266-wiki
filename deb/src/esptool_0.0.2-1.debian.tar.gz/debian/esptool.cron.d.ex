#
# Regular cron jobs for the esptool package
#
0 4	* * *	root	[ -x /usr/bin/esptool_maintenance ] && /usr/bin/esptool_maintenance
