#ifndef __USER_DEVICEFIND_H__
#define __USER_DEVICEFIND_H__

void user_platform_timer_start(char* pbuffer, struct espconn *pespconn);

#endif
