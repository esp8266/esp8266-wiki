Notice: AT added some functions so it's larger than before, if you want to compile it, please change the correspondence ld file, for example "eagle.app.v6.new.512.app1.ld"(compile for 512KB flash user1.bin with new boot), "irom0_0_seg : org = 0x40201010, len = 0x2B000",change "len = 0x2B000" to be "len = 0x31000"

1��compile options

(1) COMPILE
    Possible value: gcc
    Default value: 
    If not set, use xt-xcc by default.

(2) BOOT
    Possible value: none/old/new
      none: no need boot
      old: use boot_v1.1
      new: use boot_v1.2
    Default value: none

(3) APP
    Possible value: 0/1/2
      0: original mode, generate eagle.app.v6.flash.bin and eagle.app.v6.irom0text.bin
      1: generate user1
      2: generate user2
    Default value: 0

(3) SPI_SPEED
    Possible value: 20/26.7/40/80
    Default value: 40

(4) SPI_MODE
    Possible value: QIO/QOUT/DIO/DOUT
    Default value: QIO

(4) SPI_SIZE
    Possible value: 256/512/1024/2048/4096
    Default value: 512

For example:
    make COMPILE=gcc BOOT=new APP=1 SPI_SPEED=40 SPI_MODE=QIO SPI_SIZE=512

2��You can also use gen_misc to make and generate specific bin you needed.
    Linux: ./gen_misc.sh
    Windows: gen_misc.bat
    Follow the tips and steps.