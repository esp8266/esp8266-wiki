/*
 * copyright (c) Espressif System 2010
 *
 * mapping to ETS structures
 *
 */
#ifndef _OS_TYPES_H_
#define _OS_TYPES_H_

#define os_timer_t  ETSTimer
#define os_timer_func_t ETSTimerFunc

#endif
